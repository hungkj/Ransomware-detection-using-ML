# app.py
import joblib
import numpy as np
from flask import Flask, request, jsonify, render_template
import train_model
import os 
import pefile

# Load the trained model and scaler
model = joblib.load('rf_ransomware_model.pkl')
scaler = joblib.load('scaler.pkl')

# Initialize Flask app
app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Endpoint for predicting from feature values
@app.route('/predict', methods=['POST'])
def predict():
    data = request.json  # Expecting JSON data
    features = np.array(data['features']).reshape(1, -1)
    features_scaled = scaler.transform(features)
    
    prediction = model.predict(features_scaled)
    result = {'prediction': int(prediction[0])}
    
    return jsonify(result)

# Endpoint for file upload and prediction
@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'})
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'})
    
    if file:
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(file_path)
        
        # Extract features from the uploaded file
        features = extract_features_from_file(file_path)
        if features is None:
            return jsonify({'error': 'Feature extraction failed'})
        
        features_scaled = scaler.transform([features])
        
        # Predict
        prediction = model.predict(features_scaled)
        result = {'prediction': int(prediction[0])}
        
        return jsonify(result)

# Function to extract features from the uploaded file
def extract_features_from_file(file_path):
    try:
        pe = pefile.PE(file_path)
        
        vsize = pe.OPTIONAL_HEADER.SizeOfImage
        has_debug = 1 if hasattr(pe, 'DIRECTORY_ENTRY_DEBUG') else 0
        exports = len(pe.DIRECTORY_ENTRY_EXPORT.symbols) if hasattr(pe, 'DIRECTORY_ENTRY_EXPORT') else 0
        imports = sum([entry.dll for entry in pe.DIRECTORY_ENTRY_IMPORT]) if hasattr(pe, 'DIRECTORY_ENTRY_IMPORT') else 0
        has_relocations = 1 if hasattr(pe, 'DIRECTORY_ENTRY_BASERELOC') else 0
        has_resources = 1 if hasattr(pe, 'DIRECTORY_ENTRY_RESOURCE') else 0
        has_signature = 1 if hasattr(pe, 'DIRECTORY_ENTRY_SECURITY') else 0
        has_tls = 1 if hasattr(pe, 'DIRECTORY_ENTRY_TLS') else 0
        symbols = len(pe.DIRECTORY_ENTRY_IMPORT) if hasattr(pe, 'DIRECTORY_ENTRY_IMPORT') else 0

        features = [
            vsize,
            has_debug,
            exports,
            imports,
            has_relocations,
            has_resources,
            has_signature,
            has_tls,
            symbols
        ]
        return features
    except Exception as e:
        print(f"loi khong in duoc features {e}")
        return None

if __name__ == '__main__':
    app.run(debug=True)

    
