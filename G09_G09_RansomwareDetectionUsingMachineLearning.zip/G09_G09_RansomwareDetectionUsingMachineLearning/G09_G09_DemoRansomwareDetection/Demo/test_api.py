import requests
url = 'http://127.0.0.1:5000/'
file_path = "E:\Malware_Detection\Demo\SEB_3.7.0.682_SetupBundle.exe"
with open(file_path, 'rb') as f:
    files = {'file': f}
    response = requests.post(url, files=files)

print(response.json())
