# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np 
import matplotlib.pyplot as plt

malData=pd.read_csv("E:\Malware_Detection\MalwareData.csv", sep="|", low_memory =True)
malData.head()
malData.shape
malData.describe()
legit= malData[0:41323].drop(["legitimate"], axis=1)
mal= malData[41323::].drop(["legitimate"], axis=1)
print("So luong dataset legit la:: %s samples, %s features"%(legit.shape[0],legit.shape[1]))
print("So luong dataset chua malware la: %s samples, % s features" %(mal.shape[0],mal.shape[1]))
fig = plt.figure()
ax = fig.add_axes([0,0,1,1])
ax.hist(malData['legitimate'],20)
plt.show()

y=malData['legitimate']
malData=malData.drop(['legitimate'],axis=1)

malData=malData.drop(['Name'],axis=1)
malData=malData.drop(['md5'],axis=1)
print(" Ten Name va cac thong so md5 go thanh cong")

