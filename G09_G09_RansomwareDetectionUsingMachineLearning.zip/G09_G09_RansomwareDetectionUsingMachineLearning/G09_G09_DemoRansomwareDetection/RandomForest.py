# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np 

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report
import joblib

from sklearn.datasets import make_classification

malData=pd.read_csv("E:\Malware_Detection\MalwareData.csv", sep="|", low_memory =True)

features = malData.drop('lable', axis=1)
lables = malData['lable']
    
X_train, X_test, Y_train, y_test = train_test_split(features, lables  , test_size=0.2, random_state=42)

# Preprocess data
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train Random Forest model
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
rf_model.fit(X_train_scaled, Y_train)

# Evaluate model
y_pred = rf_model.predict(X_test_scaled)
print(classification_report(y_test, y_pred))

# Save the model and scaler
joblib.dump(rf_model, 'rf_ransomware_model.pkl')
joblib.dump(scaler, 'scaler.pkl')

